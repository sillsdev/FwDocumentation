// ---------------------------------------------------------------------------------------------
#region // Copyright (c) [!output YEAR], SIL International. All Rights Reserved.   
// <copyright from='[!output YEAR]' to='[!output YEAR]' company='SIL International'>
//		Copyright (c) [!output YEAR], SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: [!output ITEM_NAME]
// Responsibility: [!output USER_NAME]
// 
// <remarks>
// </remarks>
// ---------------------------------------------------------------------------------------------
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;

namespace [!output SAFE_NAMESPACE_NAME]
{
	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Summary description for [!output SAFE_CLASS_NAME] class.
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	public class [!output SAFE_CLASS_NAME] : System.ServiceProcess.ServiceBase
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="[!output SAFE_CLASS_NAME]"/> class.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public [!output SAFE_CLASS_NAME]()
		{
			// This call is required by the Windows.Forms Component Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitComponent call
		}

		#region Component Designer generated code
		/// ------------------------------------------------------------------------------------
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			this.ServiceName = "[!output SAFE_CLASS_NAME]";
		}
		#endregion

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing"><c>true</c> to release both managed and unmanaged 
		/// resources; <c>false</c> to release only unmanaged resources.
		/// </param>
		/// ------------------------------------------------------------------------------------
		protected override void Dispose( bool disposing ) 
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Set things in motion so your service can do its work.
		/// </summary>
		/// <param name="args">Data passed by the start command.</param>
		/// ------------------------------------------------------------------------------------
		protected override void OnStart(string[] args)
		{
			// TODO: Add code here to start your service.
		}
 
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Stop this service.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		protected override void OnStop()
		{
			// TODO: Add code here to perform any tear-down necessary to stop your service.
		}
	}
}
