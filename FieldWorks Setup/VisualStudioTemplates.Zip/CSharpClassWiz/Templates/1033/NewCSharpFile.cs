[!if !ADD_CLASS_MERGE]
// ---------------------------------------------------------------------------------------------
#region // Copyright (c) [!output YEAR], SIL International. All Rights Reserved.   
// <copyright from='[!output YEAR]' to='[!output YEAR]' company='SIL International'>
//		Copyright (c) [!output YEAR], SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: [!output ITEM_NAME]
// Responsibility: [!output USER_NAME]
// 
// <remarks>
// </remarks>
// ---------------------------------------------------------------------------------------------
using System;

namespace [!output CLASS_NAMESPACE]
{
[!endif]
	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// [!output COMMENT]
	/// </summary>
	/// ----------------------------------------------------------------------------------------
[!if ABSTRACT]
	[!output ACCESS_STRING] abstract class [!output CLASS_NAME][!output BASE_CLASS_NAME_STRING][!output INTERFACE_LIST_STRING]
[!else]
[!if SEALED]
	[!output ACCESS_STRING] sealed class [!output CLASS_NAME][!output BASE_CLASS_NAME_STRING][!output INTERFACE_LIST_STRING]
[!else]
	[!output ACCESS_STRING] class [!output CLASS_NAME][!output BASE_CLASS_NAME_STRING][!output INTERFACE_LIST_STRING]
[!endif]
[!endif]
	{
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="[!output CLASS_NAME]"/> class.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[!output ACCESS_STRING] [!output CLASS_NAME]()
		{
			// 
			// TODO: Add constructor logic here
			//
		}
	}
[!if !ADD_CLASS_MERGE]
}
[!endif]
