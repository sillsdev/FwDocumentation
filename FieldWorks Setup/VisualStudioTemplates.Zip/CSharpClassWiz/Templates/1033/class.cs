// ---------------------------------------------------------------------------------------------
#region // Copyright (c) [!output YEAR], SIL International. All Rights Reserved.   
// <copyright from='[!output YEAR]' to='[!output YEAR]' company='SIL International'>
//		Copyright (c) [!output YEAR], SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: [!output ITEM_NAME]
// Responsibility: [!output USER_NAME]
// 
// <remarks>
// </remarks>
// ---------------------------------------------------------------------------------------------
using [!output NAMESPACE];

/// --------------------------------------------------------------------------------------------
/// <summary>
/// Summary description of [!output CLASS_NAME] class.
/// </summary>
/// --------------------------------------------------------------------------------------------
public class [!output CLASS_NAME] : [!output BASE_CLASS]
{
	// TODO: Add methods, properties, fields and indexers here
}

