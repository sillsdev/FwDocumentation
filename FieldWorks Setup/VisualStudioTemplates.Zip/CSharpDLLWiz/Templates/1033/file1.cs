// ---------------------------------------------------------------------------------------------
#region // Copyright (c) [!output YEAR], SIL International. All Rights Reserved.   
// <copyright from='[!output YEAR]' to='[!output YEAR]' company='SIL International'>
//		Copyright (c) [!output YEAR], SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: Class1.cs
// Responsibility: [!output USER_NAME]
// 
// <remarks>
// </remarks>
// ---------------------------------------------------------------------------------------------
using System;

namespace [!output SAFE_NAMESPACE_NAME]
{
	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Summary description for [!output SAFE_CLASS_NAME].
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	public class [!output SAFE_CLASS_NAME]
	{
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="[!output SAFE_CLASS_NAME]"/> class.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public [!output SAFE_CLASS_NAME]()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
