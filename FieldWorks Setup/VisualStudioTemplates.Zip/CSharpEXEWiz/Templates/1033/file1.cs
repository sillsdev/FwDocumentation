// ---------------------------------------------------------------------------------------------
#region // Copyright (c) [!output YEAR], SIL International. All Rights Reserved.   
// <copyright from='[!output YEAR]' to='[!output YEAR]' company='SIL International'>
//		Copyright (c) [!output YEAR], SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: Form1.cs
// Responsibility: [!output USER_NAME]
// 
// <remarks>
// </remarks>
// ---------------------------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace [!output SAFE_NAMESPACE_NAME]
{
	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Summary description for [!output SAFE_CLASS_NAME].
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	public class [!output SAFE_CLASS_NAME] : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="[!output SAFE_CLASS_NAME]"/> class.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public [!output SAFE_CLASS_NAME]()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing"><c>true</c> to release both managed and unmanaged 
		/// resources; <c>false</c> to release only unmanaged resources. 
		/// </param>
		/// ------------------------------------------------------------------------------------
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.Size = new System.Drawing.Size(300,300);
			this.Text = "[!output SAFE_CLASS_NAME]";
		}
		#endregion

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[STAThread]
		static void Main() 
		{
			Application.Run(new [!output SAFE_CLASS_NAME]());
		}
	}
}
