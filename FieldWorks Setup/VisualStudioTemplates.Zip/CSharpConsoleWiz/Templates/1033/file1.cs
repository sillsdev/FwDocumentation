// ---------------------------------------------------------------------------------------------
#region // Copyright (c) [!output YEAR], SIL International. All Rights Reserved.   
// <copyright from='[!output YEAR]' to='[!output YEAR]' company='SIL International'>
//		Copyright (c) [!output YEAR], SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: Class1.cs
// Responsibility: [!output USER_NAME]
// 
// <remarks>
// </remarks>
// ---------------------------------------------------------------------------------------------
using System;

namespace [!output SAFE_NAMESPACE_NAME]
{
	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// Summary description for [!output SAFE_CLASS_NAME].
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	class [!output SAFE_CLASS_NAME]
	{
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		[STAThread]
		static void Main(string[] args)
		{
			//
			// TODO: Add code to start application here
			//
		}
	}
}
