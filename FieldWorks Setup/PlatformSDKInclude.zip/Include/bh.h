//=============================================================================
//  Microsoft (R) Network Monitor (tm). 
//  Copyright (C) 1991-1999. All rights reserved.
//
//  MODULE: bh.h
//
//  This is the top-level include file for all Network Monitor components.
//=============================================================================

#include "netmon.h"

//
// this file is only here as a placeholder until we get everyone to build
// with netmon.h
//
