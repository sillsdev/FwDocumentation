/*

Copyright (c) Microsoft Corporation. All rights reserved.

Module Name:
    blberr.h

Abstract:


Author:

*/

#ifndef __SDPBLB_ERROR_CODES__
#define __SDPBLB_ERROR_CODES__

#include <sdperr.h>

// First four bits - SEVERITY(11), CUSTOMER FLAG(1), RESERVED(0)
#define SDPBLB_CONF_BLOB_DESTROYED                  0xe0000300



#endif // __SDPBLB_ERROR_CODES__

